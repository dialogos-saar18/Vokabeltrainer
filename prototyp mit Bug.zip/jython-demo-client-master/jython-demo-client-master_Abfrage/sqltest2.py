import sqlite3
conn = sqlite3.connect('example.db')
def tabelle():
    c.execute('''CREATE TABLE stocks
             (date text, trans text, symbol text, qty real, price real)''')
