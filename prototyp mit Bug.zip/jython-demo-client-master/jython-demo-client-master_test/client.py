from com.clt.dialog.client import Client
import random
import java.sql.Connection
from java.sql import DriverManager 
import java.sql.SQLException
from java.lang import Class

Class.forName("sqlite-jdbc-3.21.0.1")



class Main(Client):
    def __init__(self):
        pass

    def stateChanged(self, cs):
        print "new state: " + str(cs)

    def sessionStarted(self):
        print "session started"

    def reset(self):
        print "reset"

    def output(self, value):
        self.send([1,2,3,4,5])
    def getName(self):
        return "Jython demo client"

    def error(self, throwable):
        print "error"


m = Main()
m.open(8002)


